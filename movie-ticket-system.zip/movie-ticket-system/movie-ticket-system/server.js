require("dotenv").config();
const express = require("express");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const path = require("path");
const bcrypt = require("bcryptjs");
const connectDB = require("./config/db");
const User = require("./models/User");
const Movie = require("./models/Movie");
const Show = require("./models/Show");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "local-development-secret-change-me",
  resave: false, saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 8 }
}));
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/auth", require("./routes/auth"));
app.use("/api/movies", require("./routes/movies"));
app.use("/api/bookings", require("./routes/bookings"));
app.use("/api/admin", require("./routes/admin"));

async function seedData() {
  const email = (process.env.ADMIN_EMAIL || "admin@example.com").toLowerCase();
  if (!(await User.findOne({ email }))) {
    await User.create({
      name: process.env.ADMIN_NAME || "Movie Admin", email,
      password: await bcrypt.hash(process.env.ADMIN_PASSWORD || "Admin@12345", 12), role: "admin"
    });
    console.log("Admin account created from .env settings.");
  }
  if (await Movie.countDocuments() === 0) {
    const samples = await Movie.insertMany([
      { title: "Interstellar", genre: "Sci-Fi", language: "English", duration: 169, rating: 8.7, description: "A team travels beyond this galaxy to find a future for humanity.", poster: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg" },
      { title: "The Dark Knight", genre: "Action", language: "English", duration: 152, rating: 9.0, description: "A masked hero faces a criminal mastermind in Gotham.", poster: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg" },
      { title: "Inception", genre: "Sci-Fi", language: "English", duration: 148, rating: 8.8, description: "A skilled thief enters dreams to steal and plant ideas.", poster: "https://image.tmdb.org/t/p/w500/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg" },
      { title: "Avatar: The Way of Water", genre: "Adventure", language: "English", duration: 192, rating: 7.6, description: "Return to Pandora for an epic underwater adventure.", poster: "https://image.tmdb.org/t/p/w500/t6HIqrRAclMCA60NsSmeqe9RmNV.jpg" },
      { title: "Dune: Part Two", genre: "Adventure", language: "English", duration: 166, rating: 8.5, description: "Paul Atreides unites with Chani and the Fremen.", poster: "https://image.tmdb.org/t/p/w500/1pdfLvkbY9ohJlCjQH2CZjjYVvJ.jpg" },
      { title: "Spider-Man: Across the Spider-Verse", genre: "Animation", language: "English", duration: 140, rating: 8.6, description: "Miles Morales journeys across the multiverse.", poster: "https://image.tmdb.org/t/p/w500/8Vt6mWEReuy4Of61Lnj5Xj molde.jpg".replace(" molde","") }
    ]);
    const today = new Date();
    const date = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    const times = ["10:30", "14:00", "18:30", "21:15"];
    const shows = [];
    for (const movie of samples) for (const time of times) shows.push({
      movie: movie._id, theatre: "CineMax Central", screen: "Screen 1",
      city: "Bengaluru", date, time, price: 180, rows: 6, seatsPerRow: 8
    });
    await Show.insertMany(shows);
    console.log("Sample movies and shows added.");
  }
}

connectDB().then(async () => {
  await seedData();
  const port = process.env.PORT || 3000;
  app.listen(port, () => console.log(`Movie Ticket System running at http://localhost:${port}`));
}).catch(err => { console.error("Startup failed:", err.message); process.exit(1); });
