const mongoose = require("mongoose");
const bookingSchema = new mongoose.Schema({
  bookingCode: { type: String, unique: true, required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  show: { type: mongoose.Schema.Types.ObjectId, ref: "Show", required: true },
  movieTitle: { type: String, required: true },
  theatre: { type: String, required: true },
  showDate: String,
  showTime: String,
  seats: [String],
  total: Number,
  paymentMethod: String,
  paymentStatus: { type: String, enum: ["paid", "failed"], default: "paid" },
  status: { type: String, enum: ["confirmed", "cancelled"], default: "confirmed" }
}, { timestamps: true });
module.exports = mongoose.model("Booking", bookingSchema);
