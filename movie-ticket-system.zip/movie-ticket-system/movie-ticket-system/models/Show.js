const mongoose = require("mongoose");
const showSchema = new mongoose.Schema({
  movie: { type: mongoose.Schema.Types.ObjectId, ref: "Movie", required: true },
  theatre: { type: String, required: true },
  screen: { type: String, default: "Screen 1" },
  city: { type: String, default: "Bengaluru" },
  date: { type: String, required: true },
  time: { type: String, required: true },
  price: { type: Number, required: true, min: 1 },
  rows: { type: Number, default: 6 },
  seatsPerRow: { type: Number, default: 8 },
  active: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model("Show", showSchema);
