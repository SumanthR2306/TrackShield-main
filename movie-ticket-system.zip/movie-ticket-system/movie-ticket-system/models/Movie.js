const mongoose = require("mongoose");
const movieSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String, default: "" },
  genre: { type: String, default: "Drama" },
  language: { type: String, default: "English" },
  duration: { type: Number, default: 120 },
  rating: { type: Number, min: 0, max: 10, default: 8 },
  poster: { type: String, default: "" },
  releaseDate: { type: Date },
  active: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model("Movie", movieSchema);
