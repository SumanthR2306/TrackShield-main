const mongoose = require("mongoose");
const seatSchema = new mongoose.Schema({
  show: { type: mongoose.Schema.Types.ObjectId, ref: "Show", required: true },
  seatNumber: { type: String, required: true },
  booking: { type: mongoose.Schema.Types.ObjectId, ref: "Booking" }
}, { timestamps: true });
seatSchema.index({ show: 1, seatNumber: 1 }, { unique: true });
module.exports = mongoose.model("Seat", seatSchema);
