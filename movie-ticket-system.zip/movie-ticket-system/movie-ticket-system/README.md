# CineBook — Movie Ticket Booking System

A learning/demo full-stack project using Node.js, Express, MongoDB, HTML, CSS and browser JavaScript. Payments are simulated only; no money is charged.

## Requirements
- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- VS Code

## Setup in VS Code
1. Extract the ZIP.
2. Open the `movie-ticket-system` folder in VS Code.
3. Open the VS Code terminal: Terminal → New Terminal.
4. Run `npm install`.
5. Copy `.env.example` to a new file named `.env`.
6. Update `MONGODB_URI` if using MongoDB Atlas. For local MongoDB, the example URI is fine.
7. Change `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` in `.env`.
8. Start the app with `npm start`.
9. Open `http://localhost:3000`.

On first start the app creates an admin account from `.env` and inserts sample movies and shows if the movie collection is empty.

## Admin login
Use the `ADMIN_EMAIL` and `ADMIN_PASSWORD` values in `.env` (defaults in `.env.example` are for local learning only). Open `/login.html`, then `/admin.html`.

## Demo payment
At checkout, enter UPI, Card or Cash. Confirm the browser prompt for a simulated success, or cancel it to simulate a declined payment. This is not a real payment gateway.

## Important implementation notes
- Passwords are hashed with bcrypt.
- Login state uses server-side sessions stored in MongoDB.
- Seat reservations have a unique compound index on show + seat number to prevent duplicate seat allocation.
- Demo app uses `secure: false` session cookies for localhost HTTP. Use HTTPS and secure cookies before production.
- Add CSRF protection, stronger validation, rate limiting, email verification, real payment provider webhooks, cancellation/refund rules, and production session settings before deploying publicly.
- Sample show dates are seeded for the current local calendar date. Admin can add more shows.
