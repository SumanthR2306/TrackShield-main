const express = require("express");
const Movie = require("../models/Movie");
const Show = require("../models/Show");
const Booking = require("../models/Booking");
const { requireAdmin } = require("../middleware/auth");
const router = express.Router();
router.use(requireAdmin);

router.get("/summary", async (req, res) => {
  const [movies, shows, bookings, revenue] = await Promise.all([
    Movie.countDocuments(), Show.countDocuments(), Booking.countDocuments({ status: "confirmed" }),
    Booking.aggregate([{ $match: { status: "confirmed", paymentStatus: "paid" } }, { $group: { _id: null, total: { $sum: "$total" } } }])
  ]);
  res.json({ movies, shows, bookings, revenue: revenue[0]?.total || 0 });
});
router.get("/movies", async (req, res) => res.json(await Movie.find().sort({ createdAt: -1 })));
router.post("/movies", async (req, res) => {
  const { title, poster, description, genre, language, duration, rating } = req.body;
  if (!title) return res.status(400).json({ message: "Movie title is required." });
  res.status(201).json(await Movie.create({ title, poster, description, genre, language, duration, rating }));
});
router.put("/movies/:id", async (req, res) => {
  const movie = await Movie.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!movie) return res.status(404).json({ message: "Movie not found." });
  res.json(movie);
});
router.delete("/movies/:id", async (req, res) => {
  await Movie.findByIdAndUpdate(req.params.id, { active: false });
  res.json({ message: "Movie deactivated." });
});
router.get("/shows", async (req, res) => res.json(await Show.find().populate("movie").sort({ date: 1 })));
router.post("/shows", async (req, res) => {
  const { movie, theatre, screen, city, date, time, price, rows, seatsPerRow } = req.body;
  if (!movie || !theatre || !date || !time || !price) return res.status(400).json({ message: "Movie, theatre, date, time and price are required." });
  res.status(201).json(await Show.create({ movie, theatre, screen, city, date, time, price, rows: rows || 6, seatsPerRow: seatsPerRow || 8 }));
});
router.get("/bookings", async (req, res) => res.json(await Booking.find().populate("user", "name email").sort({ createdAt: -1 })));
module.exports = router;
