const express = require("express");
const Movie = require("../models/Movie");
const Show = require("../models/Show");
const Seat = require("../models/Seat");
const router = express.Router();

router.get("/", async (req, res) => {
  const q = String(req.query.q || "").trim();
  const filter = { active: true };
  if (q) filter.title = { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" };
  res.json(await Movie.find(filter).sort({ createdAt: -1 }));
});
router.get("/:id", async (req, res) => {
  const movie = await Movie.findOne({ _id: req.params.id, active: true });
  if (!movie) return res.status(404).json({ message: "Movie not found." });
  const shows = await Show.find({ movie: movie._id, active: true }).sort({ date: 1, time: 1 });
  res.json({ movie, shows });
});
router.get("/show/:showId/seats", async (req, res) => {
  const show = await Show.findById(req.params.showId).populate("movie");
  if (!show || !show.active) return res.status(404).json({ message: "Show not found." });
  const reserved = await Seat.find({ show: show._id }).select("seatNumber -_id");
  res.json({ show, reserved: reserved.map(s => s.seatNumber) });
});
module.exports = router;
