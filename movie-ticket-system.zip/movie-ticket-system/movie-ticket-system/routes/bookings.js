const express = require("express");
const crypto = require("crypto");
const Booking = require("../models/Booking");
const Show = require("../models/Show");
const Seat = require("../models/Seat");
const { requireLogin } = require("../middleware/auth");
const router = express.Router();

router.post("/", requireLogin, async (req, res) => {
  let booking;
  try {
    const { showId, seats, paymentMethod, demoOutcome } = req.body;
    if (!showId || !Array.isArray(seats) || seats.length < 1 || seats.length > 8)
      return res.status(400).json({ message: "Select between 1 and 8 seats." });
    const cleanSeats = [...new Set(seats.map(s => String(s).toUpperCase()))];
    if (cleanSeats.length !== seats.length || cleanSeats.some(s => !/^[A-F](?:[1-8])$/.test(s)))
      return res.status(400).json({ message: "Invalid seat selection." });
    const show = await Show.findOne({ _id: showId, active: true }).populate("movie");
    if (!show) return res.status(404).json({ message: "Show not found." });
    const validSeats = [];
    for (let r = 0; r < show.rows; r++) for (let c = 1; c <= show.seatsPerRow; c++)
      validSeats.push(String.fromCharCode(65 + r) + c);
    if (cleanSeats.some(s => !validSeats.includes(s)))
      return res.status(400).json({ message: "One or more selected seats are not valid for this screen." });

    const code = "MT" + crypto.randomBytes(4).toString("hex").toUpperCase();
    booking = await Booking.create({
      bookingCode: code, user: req.session.user.id, show: show._id,
      movieTitle: show.movie.title, theatre: show.theatre, showDate: show.date,
      showTime: show.time, seats: cleanSeats, total: cleanSeats.length * show.price,
      paymentMethod: paymentMethod || "demo", paymentStatus: "paid", status: "confirmed"
    });
    // A unique index on (show, seatNumber) prevents two customers booking the same seat.
    await Seat.insertMany(cleanSeats.map(seatNumber => ({ show: show._id, seatNumber, booking: booking._id })), { ordered: true });
    if (demoOutcome === "fail") {
      await Seat.deleteMany({ booking: booking._id });
      await Booking.deleteOne({ _id: booking._id });
      return res.status(402).json({ message: "Demo payment declined. No booking was made." });
    }
    res.status(201).json({ booking });
  } catch (err) {
    if (booking) {
      await Seat.deleteMany({ booking: booking._id }).catch(() => {});
      await Booking.deleteOne({ _id: booking._id }).catch(() => {});
    }
    if (err.code === 11000) return res.status(409).json({ message: "A selected seat was just booked. Please choose another seat." });
    res.status(500).json({ message: "Booking could not be completed. Please try again." });
  }
});

router.get("/mine", requireLogin, async (req, res) => {
  res.json(await Booking.find({ user: req.session.user.id }).sort({ createdAt: -1 }));
});
router.get("/:id/qr", requireLogin, async (req, res) => {
  const booking = await Booking.findOne({ _id: req.params.id, user: req.session.user.id });
  if (!booking) return res.status(404).json({ message: "Ticket not found." });
  const QRCode = require("qrcode");
  res.json({ qr: await QRCode.toDataURL(booking.bookingCode + "|" + booking.movieTitle + "|" + booking.seats.join(",")) });
});
router.post("/:id/cancel", requireLogin, async (req, res) => {
  const booking = await Booking.findOne({ _id: req.params.id, user: req.session.user.id });
  if (!booking) return res.status(404).json({ message: "Booking not found." });
  if (booking.status === "cancelled") return res.status(400).json({ message: "Already cancelled." });
  booking.status = "cancelled";
  await booking.save();
  await Seat.deleteMany({ booking: booking._id });
  res.json({ message: "Booking cancelled." });
});
module.exports = router;
