
const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User");
const router = express.Router();

// USER REGISTRATION
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password || password.length < 8) {
      return res.status(400).json({
        message: "Enter name, email and a password of at least 8 characters."
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    if (await User.findOne({ email: normalizedEmail })) {
      return res.status(409).json({
        message: "An account with this email already exists."
      });
    }

    const user = await User.create({
      name,
      email: normalizedEmail,
      password: await bcrypt.hash(password, 12)
    });

    req.session.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    res.status(201).json({ user: req.session.user });

  } catch (err) {
    res.status(500).json({ message: "Could not create account." });
  }
});

// NORMAL USER LOGIN
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({
      email: String(email || "").toLowerCase().trim()
    });

    if (!user || !(await bcrypt.compare(password || "", user.password))) {
      return res.status(401).json({
        message: "Incorrect email or password."
      });
    }

    req.session.user = {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    };

    res.json({ user: req.session.user });

  } catch (err) {
    res.status(500).json({ message: "Login failed." });
  }
});

// SEPARATE ADMIN LOGIN
router.post("/admin-login", async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({
      email: String(email || "").toLowerCase().trim()
    });

    if (!user || user.role !== "admin") {
      return res.status(401).json({
        message: "Invalid admin email or password."
      });
    }

    const validPassword = await bcrypt.compare(
      password || "",
      user.password
    );

    if (!validPassword) {
      return res.status(401).json({
        message: "Invalid admin email or password."
      });
    }

    req.session.regenerate((err) => {
      if (err) {
        return res.status(500).json({
          message: "Could not start admin session."
        });
      }

      req.session.user = {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      };

      req.session.save((saveError) => {
        if (saveError) {
          return res.status(500).json({
            message: "Could not save admin session."
          });
        }

        res.json({ message: "Admin login successful." });
      });
    });

  } catch (err) {
    res.status(500).json({ message: "Admin login failed." });
  }
});

// LOGOUT
router.post("/logout", (req, res) => {
  req.session.destroy(() => {
    res.json({ message: "Logged out." });
  });
});

// CHECK CURRENT LOGIN
router.get("/me", (req, res) => {
  res.json({ user: req.session.user || null });
});

module.exports = router;
