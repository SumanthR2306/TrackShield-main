
const form = document.getElementById("adminLoginForm");
const message = document.getElementById("loginMessage");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  message.textContent = "Checking admin login...";

  const data = Object.fromEntries(new FormData(form));

  try {
    const response = await fetch("/api/auth/admin-login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify(data)
    });

    const responseText = await response.text();

    let result;

    try {
      result = JSON.parse(responseText);
    } catch {
      console.error("Server returned HTML or invalid JSON:", responseText);
      throw new Error(
        "Server returned a page instead of JSON. Check the API route in server.js."
      );
    }

    if (!response.ok) {
      throw new Error(result.message || "Admin login failed.");
    }

    message.textContent = "Login successful! Opening dashboard...";

    window.location.href = "/admin.html";

  } catch (error) {
    message.textContent = error.message;
    console.error(error);
  }
});
